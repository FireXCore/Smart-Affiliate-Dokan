<?php
class SAD_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function add_admin_menu() {
        add_menu_page(
            'Smart Affiliate Dokan',
            'Smart Affiliate',
            'manage_options',
            'smart-affiliate-dokan',
            array($this, 'admin_page_content'),
            'dashicons-groups',
            55
        );
    }

    public function register_settings() {
        register_setting('sad_options_group', 'sad_commission_rate', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 10,
        ));

        register_setting('sad_options_group', 'sad_discount_rate', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 10,
        ));

        add_settings_section(
            'sad_general_section',
            __('General Settings', 'smart-affiliate-dokan'),
            null,
            'smart-affiliate-dokan'
        );

        add_settings_field(
            'sad_commission_rate',
            __('Default Commission Rate (%)', 'smart-affiliate-dokan'),
            array($this, 'commission_rate_field_callback'),
            'smart-affiliate-dokan',
            'sad_general_section'
        );

        add_settings_field(
            'sad_discount_rate',
            __('Referral Discount Rate (%)', 'smart-affiliate-dokan'),
            array($this, 'discount_rate_field_callback'),
            'smart-affiliate-dokan',
            'sad_general_section'
        );
    }

    public function commission_rate_field_callback() {
        ?>
        <input type="number" name="sad_commission_rate" value="<?php echo esc_attr(get_option('sad_commission_rate', 10)); ?>" class="small-text" min="0" max="100" />%
        <?php
    }

    public function discount_rate_field_callback() {
        ?>
        <input type="number" name="sad_discount_rate" value="<?php echo esc_attr(get_option('sad_discount_rate', 10)); ?>" class="small-text" min="0" max="100" />%
        <?php
    }

    public function admin_page_content() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Smart Affiliate Dokan Settings', 'smart-affiliate-dokan'); ?></h1>
            <?php settings_errors(); ?>
            <form method="post" action="options.php">
                <?php
                settings_fields('sad_options_group');
                do_settings_sections('smart-affiliate-dokan');
                submit_button(esc_html__('Save Settings', 'smart-affiliate-dokan'));
                ?>
            </form>
        </div>
        <?php
    }
}

new SAD_Admin();