<?php
class SAD_Affiliate_Link_Generator {
    public function generate_link($product_id, $affiliate_id) {
        $product_url = get_permalink($product_id);
        if (!$product_url) {
            return false; // Invalid product URL
        }

        $affiliate_link = add_query_arg('ref', intval($affiliate_id), esc_url($product_url));

        return $affiliate_link;
    }
}

