<?php
class SAD_Referral_Discount {
    private $coupon_code;

    public function __construct() {
        add_action('wp', array($this, 'capture_referral'));
        add_action('user_register', array($this, 'generate_discount_coupon'), 10, 1);
        add_filter('woocommerce_coupon_is_valid', array($this, 'force_coupon_validity'), 10, 3);
        add_filter('dokan_coupons_to_publish', array($this, 'allow_referral_coupons'), 10, 1);
    }

    public function capture_referral() {
        // Check if 'ref' parameter is present in the URL
        if (isset($_GET['ref'])) {
            // Verify the nonce
            if (isset($_GET['_wpnonce'])) {
                $nonce = sanitize_text_field(wp_unslash($_GET['_wpnonce']));
                if (wp_verify_nonce($nonce, 'capture_referral_nonce')) {
                    // Sanitize and validate the referral ID
                    $affiliate_id = intval(sanitize_text_field(wp_unslash($_GET['ref'])));

                    // Ensure affiliate ID is valid (e.g., greater than 0)
                    if ($affiliate_id > 0) {
                        // Set a cookie for the affiliate referral, valid for 24 hours
                        setcookie('sad_affiliate_ref', $affiliate_id, time() + 3600 * 24, COOKIEPATH, COOKIE_DOMAIN);
                    }
                } else {
                    // Nonce verification failed
                    wp_die('Nonce verification failed.');
                }
            }
        }
    }

    public function generate_discount_coupon($user_id) {
        if (isset($_COOKIE['sad_affiliate_ref'])) {
            $affiliate_id = intval($_COOKIE['sad_affiliate_ref']);

            $this->coupon_code = 'REF-' . strtoupper(wp_generate_password(8, false));

            $coupon = new WC_Coupon();
            $coupon->set_code($this->coupon_code);
            $coupon->set_discount_type('percent');
            $coupon->set_amount(get_option('sad_discount_rate', 10));
            $coupon->set_individual_use(true);
            $coupon->set_usage_limit(1);
            $coupon->set_date_expires(strtotime('+7 days'));
            $coupon->set_free_shipping(false);
            $coupon->set_minimum_amount(0);
            $coupon->set_usage_limit_per_user(1);
            $coupon->set_status('publish');

            $coupon_id = $coupon->save();

            if ($coupon_id && !is_wp_error($coupon_id)) {
                if (function_exists('wc_update_coupon_lookup')) {
                    wc_update_coupon_lookup($coupon_id);
                }

                $user_info = get_userdata($user_id);
                if ($user_info) {
                    $email = $user_info->user_email;
                    $this->send_coupon_email($email, $this->coupon_code);
                }

                update_post_meta($coupon_id, 'affiliate_id', $affiliate_id);

                // Dokan specific meta
                update_post_meta($coupon_id, 'admin_coupons_enabled_for_vendor', 'yes');
                update_post_meta($coupon_id, 'coupon_commissions_type', 'default');
                update_post_meta($coupon_id, 'coupons_vendors_ids', '');
                update_post_meta($coupon_id, 'coupons_exclude_vendors_ids', '');
                update_post_meta($coupon_id, 'admin_shared_coupon_type', 'percentage');
                update_post_meta($coupon_id, 'admin_coupons_show_on_stores', 'no');

                $this->clear_caches();

                wp_cache_delete($coupon_id, 'posts');
                clean_post_cache($coupon_id);
            }
        }
    }

    private function clear_caches() {
        WC_Cache_Helper::get_transient_version('coupons', true);
        WC_Cache_Helper::invalidate_cache_group('coupons');
        wc_delete_shop_order_transients();
        wc_delete_product_transients();
        flush_rewrite_rules();
    }

    private function send_coupon_email($email, $coupon_code) {
        $site_title = get_bloginfo('name');
        $admin_email = get_option('admin_email');
        $discount_rate = get_option('sad_discount_rate', 10);
    
        // Translators: %1$d is the discount percentage, %2$s is the site title.
        $subject = sprintf(__('Your %1$d%% Discount Coupon from %2$s', 'smart-affiliate-dokan'), $discount_rate, $site_title);

        $message = $this->get_email_html_content($coupon_code, $discount_rate);
    
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            "From: {$site_title} <{$admin_email}>",
            "Reply-To: {$admin_email}"
        );
    
        wp_mail($email, $subject, $message, $headers);
    }
    
    private function get_email_html_content($coupon_code, $discount_rate) {
        $site_url = get_site_url();
        $site_title = get_bloginfo('name');
        $logo_url = get_site_icon_url();
    
        $html = '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Your Discount Coupon</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { text-align: center; margin-bottom: 20px; }
                .logo { max-width: 150px; }
                .coupon-code { background-color: #f0f0f0; padding: 10px; text-align: center; font-size: 24px; font-weight: bold; margin: 20px 0; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #777; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <img src="' . $logo_url . '" alt="' . $site_title . '" class="logo">
                    <h1>' . $site_title . '</h1>
                </div>
                <p>Thank you for registering! As a welcome gift, we\'re pleased to offer you a special discount.</p>
                <p>Here is your ' . $discount_rate . '% discount coupon:</p>
                <div class="coupon-code">' . $coupon_code . '</div>
                <p>Use this coupon to get ' . $discount_rate . '% off your next purchase.</p>
                <p>The coupon is valid for 7 days and is active immediately.</p>
                <p>To use your coupon, simply enter the code during checkout.</p>
                <p>Happy shopping!</p>
                <div class="footer">
                    <p>This email was sent from ' . $site_title . '. If you have any questions, please contact us at ' . get_option('admin_email') . '</p>
                    <p><a href="' . $site_url . '">' . $site_url . '</a></p>
                </div>
            </div>
        </body>
        </html>';
    
        return $html;
    }
    
    public function force_coupon_validity($is_valid, $coupon, $discount) {
        if (!$is_valid) {
            return $is_valid;
        }

        $coupon_id = $coupon->get_id();
        $coupon_code = $coupon->get_code();

        $enabled_for_vendor = get_post_meta($coupon_id, 'admin_coupons_enabled_for_vendor', true);
        if ($enabled_for_vendor !== 'yes') {
            return false;
        }

        $vendor_ids = get_post_meta($coupon_id, 'coupons_vendors_ids', true);
        $exclude_vendor_ids = get_post_meta($coupon_id, 'coupons_exclude_vendors_ids', true);

        if (!empty($vendor_ids) || !empty($exclude_vendor_ids)) {
            $product_authors = $this->get_cart_product_authors();
            
            if (!empty($vendor_ids)) {
                $vendor_ids = explode(',', $vendor_ids);
                if (!array_intersect($product_authors, $vendor_ids)) {
                    return false;
                }
            }

            if (!empty($exclude_vendor_ids)) {
                $exclude_vendor_ids = explode(',', $exclude_vendor_ids);
                if (array_intersect($product_authors, $exclude_vendor_ids)) {
                    return false;
                }
            }
        }

        $expiry_date = $coupon->get_date_expires();
        $usage_count = $coupon->get_usage_count();
        $usage_limit = $coupon->get_usage_limit();
        
        if ($expiry_date instanceof WC_DateTime) {
            $expiry_timestamp = $expiry_date->getTimestamp();
        } else {
            $expiry_timestamp = 0;
        }
        
        $current_time = current_time('timestamp');
        
        if ($expiry_timestamp && $expiry_timestamp <= $current_time) {
            return false;
        }
        
        if ($usage_limit !== 0 && $usage_count >= $usage_limit) {
            return false;
        }
        
        return true;
    }

    private function get_cart_product_authors() {
        $product_authors = array();
        foreach (WC()->cart->get_cart() as $cart_item) {
            $product_id = $cart_item['product_id'];
            $author_id = get_post_field('post_author', $product_id);
            if (!in_array($author_id, $product_authors)) {
                $product_authors[] = $author_id;
            }
        }
        return $product_authors;
    }

    public function allow_referral_coupons($coupons) {
        // Define a transient key
        $transient_key = 'referral_coupons';
    
        // Attempt to get cached results
        $referral_coupons = get_transient($transient_key);
    
        // If no cached data, perform the query and filter in PHP
        if ($referral_coupons === false) {
            // Query for all published coupons
            $args = [
                'post_type' => 'shop_coupon',
                'post_status' => 'publish',
                'posts_per_page' => -1, // Retrieve all coupons
                'fields' => 'ids', // Retrieve only the post IDs
            ];
    
            $query = new WP_Query($args);
            $referral_coupons = [];
    
            // Filter results by meta_key and title in PHP
            foreach ($query->posts as $post_id) {
                $title = get_the_title($post_id);
                $affiliate_id = get_post_meta($post_id, 'affiliate_id', true);
    
                // Check for affiliate_id meta and title starting with 'REF-'
                if (!empty($affiliate_id) && strpos($title, 'REF-') === 0) {
                    $referral_coupons[] = $title;
                }
            }
    
            // Cache the results using transients for 12 hours
            set_transient($transient_key, $referral_coupons, 12 * HOUR_IN_SECONDS);
        }
    
        // Merge and return the coupons
        return array_merge($coupons, $referral_coupons);
    }
    
    
}

new SAD_Referral_Discount();
