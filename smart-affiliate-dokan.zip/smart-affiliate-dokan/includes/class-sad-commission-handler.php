<?php
class SAD_Commission_Handler {
    public function process_commission($order_id) {
        $cache_key = 'sad_commission_' . $order_id;
        $commission_data = wp_cache_get($cache_key); // Check cache

        if (false === $commission_data) {
            // If cache is not available, calculate and store it
            $order = wc_get_order($order_id);
            $affiliate_id = $this->get_affiliate_from_order($order);

            // Validate affiliate_id
            if ($affiliate_id && is_int($affiliate_id)) {
                $commission_rate = $this->get_commission_rate($affiliate_id);
                $order_total = $order->get_total();
                $commission_amount = round($order_total * ($commission_rate / 100), 2);

                $commission_data = ['affiliate_id' => $affiliate_id, 'amount' => $commission_amount];
                wp_cache_set($cache_key, $commission_data, '', 3600); // Cache for 1 hour
                $this->save_commission($affiliate_id, $order_id, $commission_amount);
            } else {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    // Proper logging mechanism for debugging
                    do_action('sad_log_error', 'Invalid affiliate ID for order: ' . $order_id);
                }
            }
        }

        // Use cached data
        return $commission_data;
    }

    private function get_affiliate_from_order($order) {
        if (isset($_COOKIE['sad_affiliate'])) {
            return intval(sanitize_text_field(wp_unslash($_COOKIE['sad_affiliate']))); // Ensure data is sanitized
        }
        return false;
    }

    private function get_commission_rate($affiliate_id) {
        $rate = get_option('sad_commission_rate', 10);
        return is_numeric($rate) && $rate >= 0 ? $rate : 10; // Default to 10% if invalid
    }

    private function save_commission($affiliate_id, $order_id, $amount) {
        // Create a custom post type for commissions
        $commission_post = array(
            'post_title'    => 'Commission for Order ' . $order_id,
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_type'     => 'sad_commission',
            'meta_input'    => array(
                'affiliate_id' => $affiliate_id,
                'order_id'     => $order_id,
                'amount'       => $amount,
                'status'       => 'pending',
                'created_at'   => current_time('mysql'),
            ),
        );

        $post_id = wp_insert_post($commission_post);

        if (is_wp_error($post_id)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // Log the error using a proper logging mechanism
                do_action('sad_log_error', 'Failed to save commission for order: ' . $order_id . '. Error: ' . $post_id->get_error_message());
            }
        }
    }
}
?>
