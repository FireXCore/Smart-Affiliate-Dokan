<?php
class SAD_User_Dashboard {

    public function __construct() {
        // Add affiliate menu to Dokan dashboard navigation
        add_filter('dokan_get_dashboard_nav', array($this, 'add_affiliate_menu'));

        // Register endpoint for affiliate page
        add_action('init', array($this, 'add_endpoint'));

        // Add 'affiliate' parameter to Dokan query vars
        add_filter('dokan_query_var_filter', array($this, 'add_affiliate_endpoint'));

        // Display affiliate dashboard content
        add_action('dokan_dashboard_content_affiliate', array($this, 'affiliate_dashboard_content'));

        // Load affiliate page template using Dokan's custom template loader
        add_action('dokan_load_custom_template', array($this, 'dokan_load_affiliate_template'));
    }

    /**
     * Add affiliate menu to Dokan dashboard navigation
     */
    public function add_affiliate_menu($urls) {
        $urls['affiliate'] = array(
            'title' => esc_html__('Affiliate', 'smart-affiliate-dokan'),
            'icon'  => '<i class="fa fa-user-plus"></i>',
            'url'   => dokan_get_navigation_url('affiliate'),
            'pos'   => 71,
        );
        return $urls;
    }

    /**
     * Register endpoint for affiliate page
     */
    public function add_endpoint() {
        add_rewrite_endpoint('affiliate', EP_PAGES);
    }

    /**
     * Add 'affiliate' parameter to query vars
     */
    public function add_affiliate_endpoint($query_vars) {
        $query_vars['affiliate'] = 'affiliate';
        return $query_vars;
    }

    /**
     * Display content for affiliate dashboard page
     */
    public function affiliate_dashboard_content() {
        $user_id = get_current_user_id();
        $affiliate_link = $this->get_affiliate_link($user_id);
        $earnings = $this->get_affiliate_earnings($user_id);
        $commissions = $this->get_recent_commissions($user_id);

        ?>
        <div class="dokan-dashboard-wrap">
            <div class="dokan-dashboard-content dokan-affiliate-content">
                <article class="dokan-dashboard-area">
                    <header class="dokan-dashboard-header">
                        <h1 class="entry-title"><?php esc_html_e('Affiliate Dashboard', 'smart-affiliate-dokan'); ?></h1>
                    </header>

                    <div class="dokan-w12 dokan-dash-left">
                        <div class="dokan-panel dokan-panel-default">
                            <div class="dokan-panel-heading">
                                <strong><?php esc_html_e('Affiliate Link', 'smart-affiliate-dokan'); ?></strong>
                            </div>
                            <div class="dokan-panel-body">
                                <div class="dokan-input-group">
                                    <input type="text" class="dokan-form-control" readonly value="<?php echo esc_url($affiliate_link); ?>" onclick="this.select();">
                                    <span class="dokan-input-group-btn">
                                        <button class="dokan-btn dokan-btn-theme" type="button" onclick="copyToClipboard(this)"><?php esc_html_e('Copy', 'smart-affiliate-dokan'); ?></button>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="dokan-panel dokan-panel-default">
                            <div class="dokan-panel-heading">
                                <strong><?php esc_html_e('Earnings Overview', 'smart-affiliate-dokan'); ?></strong>
                            </div>
                            <div class="dokan-panel-body">
                                <div class="dashboard-widget big-counter">
                                    <ul class="list-inline">
                                        <li>
                                            <div class="title"><?php esc_html_e('Total Earnings', 'smart-affiliate-dokan'); ?></div>
                                            <div class="count"><?php echo wp_kses(wc_price($earnings), array('span' => array('class' => array()))); ?></div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <?php if ($commissions): ?>
                            <div class="dokan-panel dokan-panel-default">
                                <div class="dokan-panel-heading">
                                    <strong><?php esc_html_e('Recent Commissions', 'smart-affiliate-dokan'); ?></strong>
                                </div>
                                <div class="dokan-panel-body">
                                    <table class="dokan-table dokan-table-striped">
                                        <thead>
                                            <tr>
                                                <th><?php esc_html_e('Order ID', 'smart-affiliate-dokan'); ?></th>
                                                <th><?php esc_html_e('Amount', 'smart-affiliate-dokan'); ?></th>
                                                <th><?php esc_html_e('Status', 'smart-affiliate-dokan'); ?></th>
                                                <th><?php esc_html_e('Date', 'smart-affiliate-dokan'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($commissions as $commission): ?>
                                            <tr>
                                                <td><?php echo esc_html($commission->order_id); ?></td>
                                                <td><?php echo esc_html(wc_price($commission->amount)); ?></td>
                                                <td>
                                                    <span class="dokan-label <?php echo esc_attr($this->get_status_class($commission->status)); ?>">
                                                        <?php echo esc_html(ucfirst($commission->status)); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($commission->created_at))); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="dokan-alert dokan-alert-warning">
                                <?php esc_html_e('No commissions available.', 'smart-affiliate-dokan'); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="dokan-w4 dokan-dash-right">
                        <!-- Add sidebar widgets here if needed -->
                    </div>
                </article>
            </div>
        </div>

        <script>
        function copyToClipboard(button) {
            const input = button.closest('.dokan-input-group').querySelector('input');
            input.select();
            document.execCommand('copy');
            const originalText = button.textContent;
            button.textContent = '<?php esc_html_e('Copied!', 'smart-affiliate-dokan'); ?>';
            setTimeout(() => {
                button.textContent = originalText;
            }, 2000);
        }
        </script>
        <?php
    }

    /**
     * Get the status class for a commission
     */
    private function get_status_class($status) {
        switch ($status) {
            case 'completed':
                return 'dokan-label-success';
            case 'pending':
                return 'dokan-label-warning';
            case 'cancelled':
                return 'dokan-label-danger';
            default:
                return 'dokan-label-default';
        }
    }

    /**
     * Generate affiliate link for the user
     */
    private function get_affiliate_link($user_id) {
        $affiliate_id = $user_id; // Or use any other custom variable or meta field
        return add_query_arg('ref', $affiliate_id, home_url());
    }

    /**
     * Calculate total earnings for the affiliate with caching
     */
    private function get_affiliate_earnings($user_id) {
        // Define a cache key
        $cache_key = 'sad_affiliate_earnings_' . $user_id;
        $earnings = wp_cache_get($cache_key);
    
        if ($earnings === false) {
            // Use WP_Query to retrieve earnings instead of direct SQL
            $args = array(
                'post_type'      => 'sad_commission', // Assuming 'sad_commission' is the custom post type
                'post_status'    => 'approved', // Filter by approved status
                'author'         => $user_id, // Filter by affiliate ID
                'fields'         => 'ids', // Only get post IDs for performance
                'posts_per_page' => -1, // Get all posts
            );
    
            $query = new WP_Query($args);
            
            // Calculate total earnings from the retrieved posts
            $earnings = 0;
            if ($query->have_posts()) {
                foreach ($query->posts as $post_id) {
                    $amount = get_post_meta($post_id, 'amount', true); // Assuming amount is stored as post meta
                    $earnings += (float)$amount; // Sum the amounts
                }
            }
    
            // Set the cache
            wp_cache_set($cache_key, $earnings, '', 3600);
        }
    
        return $earnings ? $earnings : 0; // Return earnings or 0 if no earnings found
    }
    

    /**
     * Get recent commissions for the affiliate with caching
     */
    private function get_recent_commissions($user_id, $limit = 5) {
        // Define a cache key
        $cache_key = 'sad_recent_commissions_' . $user_id . '_' . $limit;
        $commissions = wp_cache_get($cache_key);
    
        if ($commissions === false) {
            // Use WP_Query to retrieve recent commissions instead of direct SQL
            $args = array(
                'post_type'      => 'sad_commission', // Assuming 'sad_commission' is the custom post type
                'post_status'    => 'publish', // Assuming you want only published commissions
                'author'         => $user_id, // Filter by affiliate ID
                'posts_per_page' => $limit, // Limit the number of results
                'orderby'        => 'date', // Order by creation date
                'order'          => 'DESC', // Most recent first
            );
    
            $query = new WP_Query($args);
            
            // Store the results in an array
            $commissions = array();
            if ($query->have_posts()) {
                foreach ($query->posts as $post) {
                    $commissions[] = array(
                        'ID' => $post->ID,
                        'amount' => get_post_meta($post->ID, 'amount', true), // Assuming amount is stored as post meta
                        'created_at' => get_the_date('', $post->ID), // Get the creation date of the post
                    );
                }
            }
    
            // Cache the results
            wp_cache_set($cache_key, $commissions, '', 3600);
        }
    
        return $commissions;
    }
    

    /**
     * Load affiliate page template with Dokan's sidebar and custom content
     */
    public function dokan_load_affiliate_template($query_vars) {
        if (isset($query_vars['affiliate'])) {
            ?>
            <div class="dokan-dashboard-wrap">
                <?php
                // Load content before the dashboard (like sidebar)
                do_action('dokan_dashboard_content_before');
                ?>
                <div class="dokan-dashboard-content">
                    <article class="dashboard-content-area">
                        <?php do_action('dokan_dashboard_content_affiliate'); ?>
                    </article>
                </div>
            </div>
            <?php
        }
    }
}
