<?php
/**
 * Plugin Name: Smart Affiliate for Dokan
 * Plugin URI: https://firexcore.com/smart-affilite-dokan/
 * Description: A smart affiliate system for WooCommerce and Dokan multi-vendor marketplace.
 * Version: 1.0.0
 * Author: FireXCore
 * Author URI: https://firexcore.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: smart-affiliate-dokan
 * Domain Path: /languages
 * Requires Plugins: woocommerce, dokan-lite
 */

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SAD_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('SAD_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SAD_VERSION', '1.0');

function sad_enqueue_styles() {
    if ( is_page('affiliate-page') ) {
        wp_enqueue_style(
            'affiliate-dashboard',
            plugin_dir_url( __FILE__ ) . 'assets/css/affiliate-dashboard.css',
            array(),
            SAD_VERSION,
            'all'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'sad_enqueue_styles' );


// Include necessary files
require_once SAD_PLUGIN_PATH . 'includes/class-sad-affiliate-link-generator.php';
require_once SAD_PLUGIN_PATH . 'includes/class-sad-commission-handler.php';
require_once SAD_PLUGIN_PATH . 'includes/class-sad-admin.php';
require_once SAD_PLUGIN_PATH . 'includes/class-sad-user-dashboard.php';
require_once SAD_PLUGIN_PATH . 'includes/class-sad-referral-discount.php';

// Main plugin class
class Smart_Affiliate_Dokan {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('plugins_loaded', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'add_settings_link'));
    }

    public function init() {
        if (class_exists('WooCommerce') && class_exists('WeDevs_Dokan')) {
            $this->init_hooks();
        } else {
            add_action('admin_notices', array($this, 'plugin_dependency_notice'));
        }
    }

    private function init_hooks() {
        add_action('init', array($this, 'register_affiliate_role'));
        add_action('woocommerce_thankyou', array($this, 'process_affiliate_commission'), 10, 1);
        add_filter('woocommerce_product_get_permalink', array($this, 'modify_product_permalink'), 10, 2);
        add_action('init', array($this, 'init_user_dashboard'), 5);
    }

    public function init_user_dashboard() {
        if (class_exists('WeDevs_Dokan')) {
            new SAD_User_Dashboard();
        }
    }

    public function register_affiliate_role() {
        add_role(
            'sad_affiliate',
            __('Smart Affiliate', 'smart-affiliate-dokan'),
            array(
                'read' => true,
                'edit_posts' => false,
                'delete_posts' => false,
            )
        );
    }

    public function process_affiliate_commission($order_id) {
        $commission_handler = new SAD_Commission_Handler();
        $commission_handler->process_commission($order_id);
    }

    public function modify_product_permalink($permalink, $product) {
        $affiliate_id = isset($_COOKIE['sad_affiliate']) ? sanitize_text_field(wp_unslash($_COOKIE['sad_affiliate'])) : '';
        if ($affiliate_id) {
            $permalink = add_query_arg('ref', $affiliate_id, $permalink);
        }
        return $permalink;
    }
    

    public function plugin_dependency_notice() {
        echo '<div class="error"><p>' . esc_html__('Smart Affiliate Dokan requires WooCommerce and Dokan to be installed and active.', 'smart-affiliate-dokan') . '</p></div>';
    }

    public function activate() {
        if (!class_exists('SAD_User_Dashboard')) {
            require_once SAD_PLUGIN_PATH . 'includes/class-sad-user-dashboard.php';
        }
        $user_dashboard = new SAD_User_Dashboard();
        $user_dashboard->add_endpoint();
        flush_rewrite_rules();
    }

    public function deactivate() {
        flush_rewrite_rules();
    }

    public function add_settings_link($links) {
        $settings_link = '<a href="admin.php?page=smart-affiliate-dokan">Settings</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}

// Initialize the plugin
function SAD() {
    return Smart_Affiliate_Dokan::get_instance();
}

SAD();
