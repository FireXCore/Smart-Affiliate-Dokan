=== Smart Affiliate for Dokan ===
Contributors: FireXCore
Tags: affiliate, commission, dokan, multi-vendor, woocommerce
Requires at least: 5.0
Tested up to: 6.6
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A robust affiliate marketing system for WooCommerce and Dokan, allowing vendors to manage affiliate links and track commissions effortlessly.

== Description ==

Smart Affiliate for Dokan integrates affiliate marketing functionality into WooCommerce and Dokan multi-vendor marketplaces. This plugin allows sellers to generate unique affiliate links, track commissions, and manage affiliate marketing directly from their dashboards.

**Main features include:**

- Creation of unique affiliate links for each product.
- Commission management with a default percentage (10%).
- Automatic commission calculation for orders placed through affiliate links.
- Vendor dashboard for tracking commissions, order status, and reports.
- Admin panel for configuring commission percentages and settings.
- Works seamlessly with WooCommerce and Dokan.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/smart-affiliate-dokan` directory, or install the plugin directly through the WordPress plugins screen.
2. Activate the plugin via the 'Plugins' screen in WordPress.
3. Ensure that both WooCommerce and Dokan are installed and activated.
4. Go to the settings page under 'Settings' > 'Affiliate Settings' to configure the plugin.
5. Adjust the default commission percentage and other settings as needed.

== Frequently Asked Questions ==

= How does the plugin work? =

The plugin automatically generates affiliate links for products in your store. When a customer makes a purchase through an affiliate link, a commission is calculated based on the predefined percentage. Commissions are stored in the database and can be viewed by the vendor in their dashboard.

= Can I control the commission percentage? =

Yes, the default commission percentage (default is 10%) can be adjusted in the plugin settings page.

= Does the plugin work with WooCommerce and Dokan? =

Yes, it integrates seamlessly with both WooCommerce and Dokan. Sellers can create affiliate links for products and track their commissions from their vendor dashboard.

= Will the plugin work if WooCommerce or Dokan is not installed? =

No, the plugin requires WooCommerce and Dokan to be installed and activated. A warning will be displayed if either plugin is not installed.

== Screenshots ==

1. **Settings Page:** Configure default commission percentage and other settings.
2. **Vendor Dashboard:** View detailed reports of commissions and order status.
3. **Affiliate Links:** Generate affiliate links for individual products.

== Changelog ==

= 1.0.0 =
* Initial release of the plugin.
* Ability to generate affiliate links for products.
* Automatic commission calculation for affiliate purchases.
* Vendor and admin dashboards for commission tracking and settings.

== Upgrade Notice ==

= 1.0.0 =
Initial release of Smart Affiliate for Dokan. Install this version to start tracking affiliate commissions and managing affiliate links on your multi-vendor marketplace.

== License ==

This plugin is licensed under the GPL v2 or later. For more information, visit [GPL License](https://www.gnu.org/licenses/gpl-2.0.html).
